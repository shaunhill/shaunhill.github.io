
Shaun Dean Hill
=========================

 >9 years experience in the IT industry with 5+ years experience in data related design, implementation, and support. Specializing in data processing, profiling and integration. With strong design, modelling and visualization experience. I have a diverse understanding of a variety of technologies, while maintaining an in-depth knowledge of technologies in which I specialize. This gives me the perspective to take into account per-existing, current and potential investments, and integrate these considerations into a solution.


Technologies
--------------------

   >Java, Python, Pandas , ABAP, T-SQL, MS SSIS, MS SSRS, SAP BW, SAP BEx Query Designer, SAP Design Studio, SAP Web Intelligence, SAP Crystal Reports, R, Dplyr GGplot2, D3.js, HTML, CSS, Javascript, Twitter Bootstrap, JQuery, MongoDB, MS SQL Server, SAP AAOE, SAP ECC, Windows Server, VMware ESX, Github, Tableau

Corporate Experience
--------------------
2016-11 - Present : *BI Developer/Consultant, Freelance [shaundh.co.za](http://shaunhill.github.io/) (Gauteng, South Africa)*

  >Requirements gathering, design and, implementation of business intelligence solutions which are both functional and practical. In the ever changing world of data, I seek to gain knowledge and apply what I have learned to help others to do the same.

---

2016-06 - 2016-10 : *BI Technical Consultant, [Zetta Solutions (Pty)](http://www.zettasolutions.com/) (Fourways, Gauteng, South Africa)*

  >Worked closely with senior management and staff to adhere to tight deadlines and weekly deliverables. Maintaining and
  enhancing existing developments, while implementing new developments to insuring project progress, information availability and fast turn around times.
  Utilized various technologies implementing a wide range of solutions including:
  >
  - Outlining a data strategy, to lay the ground work for future developments.
  - Designing and developing a Microsoft SQL 2014 database to accommodate the front-end and the various reports and dashboards.
  - Using tools like T-SQL, SQL Server Integration Services, and excel to integrate and standardize both historical data and master-data
  - Using ASP.net Dynamic Data to create a multi-user web based data capture system.
  - Designing, developing and refactoring several Tableau 10 dashboard and reports, this included integration with the clients WMS (Web Map Service) and [shapefiles](http://doc.arcgis.com/en/arcgis-online/reference/shapefiles.htm).



---

2014-08 - 2016-07 : *BI Developer/Consultant, Freelance [shaundh.co.za](http://shaunhill.github.io/) (Gauteng, South Africa)*

>Professionally I worked on various SAP BW/BO project, but my time was mainly focused on upskilling and diversifying my skill set. I worked with various technologies including [R (Programming language)](https://en.wikipedia.org/wiki/R_(programming_language)), [MongoDB (NoSQL Database)](https://en.wikipedia.org/wiki/MongoDB)],and [d3.js (Low Level Visualization library)](https://en.wikipedia.org/wiki/D3.js).
Some examples of projects worked on during this time :
>
- Creating a SAP Design Studio dashboard for mining quantities and equipment KPIs
- Various SAP BW projects which includes working with procurement, financial, mining, GPS, and equipment related data, as well enhancing standard and custom developments.
- Extracting and analysing openstreetmap.org data with the intention of correlated the data with data extracted from company websites to identify missing stores/branches, and then adding the delta to openstreetmap.org.
- Creating a Java based web crawler search websites for company contact information.

---

<div style="page-break-after: always;"></div>

2012-08 - 2014-07 : *BI Developer, [MCC Group](https://www.mccgroup.co.za) (Midrand, Gauteng, South Africa)*

  >Being involved in all aspects of the enterprise data warehouse model, I gained a wide range of BI and data related skills. Successfully designing, implementing and supporting both Microsoft SQL and SAP BW data warehouses, As well as reporting and analytical developments in SAP Business Objects, Qlikview, and SSRS. I also assisted in other data related tasks, e.g. using LSMW and BAPIs to do data take on, and master data generation.

---

  2010-08 - 2012-07 : *Database / Systems Administrator, [MCC Group](https://www.mccgroup.co.za)  (Midrand, Gauteng, South Africa).*

  >Responsible for the administration and maintenance of servers both physical and virtual, network infrastructure, IT related procurement and supplier management. It was during this time that I gained my initial exposure to databases and T-SQL. As my knowledge grew I took over the responsibility for databases and applications, and ultimately business intelligence.

---

  2007-08 - 2010-07 : *Network Administrator, [Eqstra Holdings](https://www.eqstra.co.za) (Meadowdale, Johannesburg, South Africa).*

  >Worked alongside other IT infrastructure staff and systems staff to deliver a high level of support and customer service in accordance with strict SLA agreements, ultimately ensuring that clients experience minimal downtime and an optimal user experience.


Core Skills
--------------------

*Design / Modeling / Planning*

  >Strong knowledge of database(relational and non-Relational) and data warehouse design principles(bottom-up and top-down). With experience working on implementation and design teams, doing requirements gathering, gap analyses, development, consultancy, post implementation support and training.

*Data Processing / Integration  / ETL*

  >A large portion of my experience is focused towards ETL, with it mostly split between T-SQL/SSIS and SAP BW/ABAP, extracting and integrating form relational, non-relation, flat-file, and web APIS. I have also used occasional use data processing libraries in R and python.

*Development / Programming*

  >I am familiar with various design patterns and programming paradigms and have manly worked with Python and Java to develop a few data related systems. Also most of my exposure to programming languages are data originated, I also have experience with, front-end, web, and as mentioned below visualization development.  

*Visualization / Reporting*

  >Visualization and reporting are a major part of my skill sets. Most recently I worked with Tableau and SAP Business Objects. Although sometime ago, I also made extensive use of Microsoft SSRS. In my personal time I work with R-GGplot and D3.js.

*Data Analysis / Profiling*

  > Experience in using SQL, R, Excel and other Excel related add-ons like SAP AAOE for analyses and profiling. I am also familiar with the core concepts of descriptive and inferential statistics, as well as machine learning.

Contact Details
--------------------

   >***Email*** : shaun4z@live.co.za |  ***Cell*** : +27 (72) 535 9760 |  ***Linkedin*** : <https://za.linkedin.com/in/shaundh>
